<script>
	import Products from '../interfaces/products/Products.svelte';
</script>

<!-- Header-->
<header class="py-5 bg-gradient-to-r from-pink-500 to-yellow-500">
	<div class="container px-4 px-lg-5 my-3">
		<div class="text-center text-white">
			<h1 class="display-4 fw-bolder">Shop in style</h1>
		</div>
	</div>
</header>

<Products />
